SKAPADEN – proiect sursă Android + iOS
=======================================

Acesta NU este încă un APK sau AAB semnat. Este proiectul jocului, pregătit pentru împachetare. Pentru publicare sunt necesare semnarea aplicației, contul Google Play și verificarea cerințelor magazinului.

ANDROID PE WINDOWS 10
---------------------
1. Instalează Node.js 22 LTS sau mai nou: https://nodejs.org/
2. Instalează cea mai recentă versiune Android Studio compatibilă cu Windows 10 64-bit: https://developer.android.com/studio
3. În Android Studio, termină Setup Wizard și acceptă instalarea Android SDK.
4. Deschide Tools > SDK Manager:
   - SDK Platforms: instalează Android 16 / API 36.
   - SDK Tools: asigură-te că sunt instalate Android SDK Build-Tools, Android SDK Command-line Tools și Android SDK Platform-Tools.
5. Dezarhivează proiectul într-un folder simplu, de exemplu C:\SKAPADEN.
6. Dublu-click pe PORNESTE-ANDROID-WINDOWS.bat. Scriptul instalează dependențele, construiește jocul, creează/sincronizează proiectul Android și deschide Android Studio.
7. În Android Studio, așteaptă Gradle Sync. Dacă apare o solicitare de instalare/actualizare SDK sau Gradle, acceptă.
8. Pentru APK: Build > Generate Signed Bundle / APK > APK. Creează un keystore dacă nu ai unul, alege release și finalizează.
9. Pentru Google Play: repetă pașii de generare și alege Android App Bundle (AAB), nu APK. Google Play cere AAB pentru aplicațiile noi.
10. Păstrează în siguranță fișierul keystore (.jks), aliasul și parolele. Fă o copie de rezervă offline. Nu le trimite nimănui.

TESTARE
-------
- Activează Developer options și USB debugging pe telefon sau copiază APK-ul pe telefon.
- Instalează APK-ul și testează jocul: start, zbor, obstacole, monede, diamante, sunete, pauză și reluare.
- Dezactivează USB debugging după test, dacă nu mai ai nevoie de el.

GOOGLE PLAY
-----------
- Play Console: https://play.google.com/console/
- Înregistrarea contului costă 25 USD o singură dată; trebuie să ai cel puțin 18 ani și să treci verificările Google.
- Pentru conturile personale noi create după 13 noiembrie 2023, Google cere un test închis cu cel puțin 12 testeri înscriși continuu timp de 14 zile înainte de a solicita accesul la producție.
- Începând cu 31 august 2026, aplicațiile noi trimise la Google Play trebuie să vizeze Android 16 / API 36 sau mai nou. Proiectul folosește Capacitor 8 și trebuie verificat în Android Studio că target SDK este 36 sau mai nou înainte de publicare.
- Completează pagina magazinului, iconița, capturile de ecran, politica de confidențialitate și declarațiile Data safety / conținut cerute de Play Console.

APPLE / iOS
------------
Windows nu poate compila local o aplicație iOS. Pentru IPA/App Store este necesar un Mac cu Xcode sau un serviciu de build macOS în cloud și cont Apple Developer.

COMENZI MANUALE (din folderul proiectului)
------------------------------------------
npm install
npm run build
npx cap add android
npx cap sync android
npx cap open android

STADIUL FUNCȚIILOR COMERCIALE
-----------------------------
În această arhivă NU sunt încă integrate SDK-urile Google Mobile Ads (AdMob) sau Google Play Billing. Nu afișează reclame și nu procesează cumpărături reale. Acestea necesită configurarea aplicației în AdMob / Play Console, identificatori de aplicație și produse, precum și testare pe Android. Nu publica jocul cu butoane de cumpărare sau reclame simulate.

NOTĂ
----
Jocul este un prototip sursă. Această versiune include salvarea locală a recordului, monedelor, diamantelor și setării de sunet, un magazin cu 10 skin-uri (monede virtuale), recompensă zilnică de 100 monede și o misiune zilnică (20 monede colectate pentru 150 monede bonus). Progresul este salvat local pe dispozitiv în browserul aplicației. Skin-urile și recompensele sunt funcții virtuale locale, nu cumpărături cu bani reali. Înainte de publicare verifică drepturile asupra numelui SKAPADEN, graficii și sunetelor, testează pe dispozitive reale și completează toate cerințele de conformitate ale Google Play.

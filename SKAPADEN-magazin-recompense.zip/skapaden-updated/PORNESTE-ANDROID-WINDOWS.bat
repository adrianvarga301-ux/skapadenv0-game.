@echo off
setlocal
title SKAPADEN - Android build
echo ======================================
echo        SKAPADEN - Android setup
echo ======================================
where node >nul 2>nul
if errorlevel 1 (
  echo Node.js nu este instalat. Instaleaza Node.js LTS si redeschide fereastra.
  pause
  exit /b 1
)
where npm >nul 2>nul
if errorlevel 1 (
  echo npm nu a fost gasit. Reinstaleaza Node.js LTS.
  pause
  exit /b 1
)
echo [1/4] Instalez dependintele...
call npm install
if errorlevel 1 goto fail
echo [2/4] Construiesc jocul...
call npm run build
if errorlevel 1 goto fail
if not exist android (
  echo [3/4] Creez proiectul Android...
  call npx cap add android
  if errorlevel 1 goto fail
) else (
  echo [3/4] Proiectul Android exista deja.
)
echo [4/4] Sincronizez fisierele...
call npx cap sync android
if errorlevel 1 goto fail
echo.
echo Gata. Deschid proiectul Android Studio...
call npx cap open android
echo.
echo In Android Studio: Build ^> Generate Signed Bundle / APK.
echo Alege APK pentru instalare directa sau Android App Bundle pentru Google Play.
pause
exit /b 0
:fail
echo.
echo A aparut o eroare. Verifica mesajul de mai sus si cerintele din README-RO.txt.
pause
exit /b 1
